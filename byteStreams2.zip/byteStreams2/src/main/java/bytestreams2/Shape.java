package bytestreams2;

public interface Shape {
    public void draw();
}
